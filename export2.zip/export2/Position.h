#ifndef POSITION_H
#define POSITION_H

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <SDL.h>
#include "Math.h"


typedef struct Position {
	int ENTITY_ID;
	Vec2 value;
} Position;

#endif // !POSITION_H
