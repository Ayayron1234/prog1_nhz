#ifndef MOVEMENTCONTROLLERSYSTEMS_H
#define MOVEMENTCONTROLLERSYSTEMS_H

#include "ECS.h"


void MovementController_update(Layout* currentLayout, MovementController* movementController, double delta_t);

#endif // !MOVEMENTCONTROLLERSYSTEMS_H
