#pragma once
#include "ECS.h"
#include "Position.h"


void Position_moveBy(Position* position, Vec2 amount);
