#pragma once
#include <time.h>
#include <math.h>
#include "Animation.h"
#include "ECS.h"


void Animation_update(ComponentLists* components, Animation* animation);
