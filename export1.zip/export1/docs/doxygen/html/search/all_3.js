var searchData=
[
  ['game_0',['Game',['../struct_game.html',1,'']]],
  ['gameappearance_1',['GameAppearance',['../struct_game_appearance.html',1,'']]],
  ['gametime_2',['GameTime',['../struct_game_time.html',1,'']]]
];
