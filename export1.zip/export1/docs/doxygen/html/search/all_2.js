var searchData=
[
  ['editor_0',['Editor',['../struct_editor.html',1,'']]]
];
